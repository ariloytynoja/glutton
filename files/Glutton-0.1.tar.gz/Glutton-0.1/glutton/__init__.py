__version__ = 0.1
__name__ = 'glutton'
__all__ = []

